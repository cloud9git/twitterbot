import tweepy
import datetime
import time
api_key= "lTjdQI3dcAhDo6KbI2BoQFDqQ"
api_key_secet= "gyLcBP0mKHntjjn4BDcvXXlecwHcpTbJmj9QEHp3XL0DwDoFcX"
access_token= "1241960534322237440-R9aWbH4auID75Z97UywmqoGaZDY6FS"
access_token_secret= "HqUH9NHktUOWLtdCz045iWSdGoTb077sNHBQtY7ONdSen"
auth= tweepy.OAuthHandler(api_key,api_key_secet)
auth.set_access_token(access_token,access_token_secret)
api= tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=True)
user= api.me()
print(user.screen_name)


# to check or verify the credentials
try:
    api.verify_credentials()
    print("Authentication OK")
except:
    print("Error during authentication")

# # to get the name of all followers:
# for follower in tweepy.Cursor(api.followers).items():
#     print(follower.name)

# to like the tweet by  searching special keyword:
for tweet in api.search(q="Python", lang="en", nrTweets=10):
    try:
        print("tweet liked")
        tweet.favorite()

        time.sleep(10)
    except tweepy.TweepError as e:
        print(e.reason)
    except StopIteration:
        break


# to like the recent timeline tweets as we increase the value of count , the more tweet will be liked:
# tweets = api.home_timeline(count=1)
# tweet = tweets[0]
# print(f"Liking tweet {tweet.id} of {tweet.author.name}")
# api.create_favorite(tweet.author.name)